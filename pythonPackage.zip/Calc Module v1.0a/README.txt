//CALC MODULE V1.0a


Setup:


Just one line of code!

import calc





Commands:

math.add(num1, num2)
Adds num1 and num2 together.
For example:
math.add(12, 3)

your answer is: 15




math.substract(num1, num2)
Substracts num1 and num2.
For example:
math.substract12, 3)

your answer is: 9




math.multiply(num1, num2)
Multiplies num1 and num2.
For example:
math.multiply(12, 3)

your answer is: 36




math.divide(num1, num2)
Adds num1 and num2 together.
For example:
math.divide(12, 3)

your answer is: 4







This is unclaimed, but i would appreciate credit if you use this at all.